local lastEngine, lastBody, lastCrash = nil, nil, 0
local lastELSState, lastELSTs = nil, 0
local wasDriver, lastDriverEventTs = false, 0
local lastVehWhileDriver = 0
local lastSpeed = 0.0

local MIN_IMPACT_SPEED = (Config.Crash and Config.Crash.MinImpactSpeedMPH) or 10
local MIN_SPEED_DROP   = (Config.Crash and Config.Crash.MinSpeedDropMPH)   or 8

local function dbg(msg)
    if Config.Debug then print('[EKS_IDR][CLIENT] ' .. msg) end
end

local function normalizePlate(p)
    if not p then return 'UNKNOWN' end
    p = tostring(p)
    return (p:gsub('^%s*(.-)%s*$', '%1'))
end

local function isTrackedVehicle(veh)
    if not veh or veh == 0 then return false end
    if Config.TrackAll then return true end
    local name = GetDisplayNameFromVehicleModel(GetEntityModel(veh))
    if not name then return false end
    return Config.IDRModels[string.lower(name)] == true
end

local function mphFromEntity(veh)
    return GetEntitySpeed(veh) * 2.236936
end

local function streetAndLimit(coords)
    local s1, s2 = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local primary = GetStreetNameFromHashKey(s1)
    local cross   = (s2 and s2 ~= 0) and GetStreetNameFromHashKey(s2) or nil
    local street  = primary or cross or 'Unknown'
    local low = string.lower(street)
    local limit = (low:find('fwy') or low:find('hwy') or low:find('freeway') or low:find('highway')) and 65 or 30
    return street, limit
end

local function gatherMeta(veh)
    local plate  = normalizePlate(GetVehicleNumberPlateText(veh))
    local coords = GetEntityCoords(veh)
    local street, limit = streetAndLimit(coords)
    local speedMPH  = mphFromEntity(veh)
    local engine    = math.floor(math.min(GetVehicleEngineHealth(veh), GetVehicleBodyHealth(veh))) 
    local els       = IsVehicleSirenOn(veh)
    return {
        plate  = plate,
        street = street,
        limit  = math.floor(limit + 0.5),
        speed  = math.floor(speedMPH + 0.5),
        engine = engine,
        els    = els,
    }
end

AddEventHandler('onResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
end)

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

CreateThread(function()
    while true do
        Wait(250)

        local ped = PlayerPedId()
        local inVeh = IsPedInAnyVehicle(ped, false)

        if not inVeh then
            if wasDriver and lastVehWhileDriver ~= 0 and (GetGameTimer() - lastDriverEventTs > 1500) then
                lastDriverEventTs = GetGameTimer()
                wasDriver = false
                dbg('Driver Left Vehicle')
                local meta = gatherMeta(lastVehWhileDriver); meta.type = 'DRIVER_LEFT'
                TriggerServerEvent('eks_idr:recordEntry', meta)
            end
            lastEngine, lastBody, lastSpeed = nil, nil, 0.0
            lastVehWhileDriver = 0
        else
            local veh = GetVehiclePedIsIn(ped, false)
            local isDriver = (GetPedInVehicleSeat(veh, -1) == ped)
            local tracked = isTrackedVehicle(veh)

            if isDriver and tracked then
                if not wasDriver and (GetGameTimer() - lastDriverEventTs > 1500) then
                    lastDriverEventTs = GetGameTimer()
                    wasDriver = true
                    lastVehWhileDriver = veh
                    dbg('New Driver Detected')
                    local meta = gatherMeta(veh); meta.type = 'DRIVER_CHANGE'
                    TriggerServerEvent('eks_idr:recordEntry', meta)
                end

                local eng = GetVehicleEngineHealth(veh)
                local bod = GetVehicleBodyHealth(veh)
                local speedNow = mphFromEntity(veh)
                local speedDrop = (lastSpeed or 0.0) - speedNow
                local collided = HasEntityCollidedWithAnything(veh)

                local engineDrop = lastEngine and (lastEngine - eng) or 0.0
                local bodyDrop   = lastBody   and (lastBody   - bod) or 0.0

                local engineTrig = engineDrop >= (Config.Crash.EngineDropThreshold or 20.0)
                local bodyTrig   = bodyDrop   >= (Config.Crash.BodyDropThreshold   or 15.0)
                local collisionTrig = collided and ((lastSpeed or 0.0) >= MIN_IMPACT_SPEED) and (speedDrop >= MIN_SPEED_DROP)

                if (engineTrig or bodyTrig or collisionTrig)
                and (GetGameTimer() - lastCrash > (Config.Crash.CooldownSeconds or 3) * 1000) then
                    local meta = gatherMeta(veh); meta.type = 'DAMAGE'
                    dbg(string.format('Damage logged (engDrop=%.1f bodyDrop=%.1f collided=%s spd=%.1f drop=%.1f street=%s)',
                        engineDrop, bodyDrop, tostring(collided), speedNow, speedDrop, meta.street))
                    TriggerServerEvent('eks_idr:recordEntry', meta)
                    lastCrash = GetGameTimer()
                end

                lastEngine, lastBody = eng, bod
                lastSpeed = speedNow

                local elsOn = IsVehicleSirenOn(veh)
                if lastELSState == nil then
                    lastELSState = elsOn
                elseif elsOn ~= lastELSState and (GetGameTimer() - lastELSTs > 1000) then
                    local meta = gatherMeta(veh)
                    meta.type = elsOn and 'ELS_ON' or 'ELS_OFF'
                    dbg('ELS toggle: ' .. meta.type)
                    TriggerServerEvent('eks_idr:recordEntry', meta)
                    lastELSState = elsOn
                    lastELSTs = GetGameTimer()
                end
            else
                if wasDriver and lastVehWhileDriver ~= 0 and (GetGameTimer() - lastDriverEventTs > 1500) then
                    lastDriverEventTs = GetGameTimer()
                    wasDriver = false
                    dbg('Driver Left Vehicle (lost seat)')
                    local meta = gatherMeta(lastVehWhileDriver); meta.type = 'DRIVER_LEFT'
                    TriggerServerEvent('eks_idr:recordEntry', meta)
                end
                lastEngine, lastBody, lastSpeed = nil, nil, 0.0
                if not isDriver then lastVehWhileDriver = 0 end
            end
        end
    end
end)

exports.ox_target:addGlobalVehicle({
    {
        name = 'eks_idr:view',
        label = 'View IDR',
        icon = 'fa-solid fa-car-burst',
        distance = Config.TargetDistance,
        canInteract = function(entity)
            return isTrackedVehicle(entity)
        end,
        onSelect = function(data)
            local plate = normalizePlate(GetVehicleNumberPlateText(data.entity))
            lib.callback('eks_idr:getLogs', false, function(logs)
                SetNuiFocus(true, true)
                SendNUIMessage({ action = 'open', plate = plate, logs = logs.entries or {} })
            end, plate)
        end
    }
})
