fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'EKS_IDR'
author 'Cowboy - Echo Kilo Studios'
description 'Incident Data Recorder'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/styles.css',
    'html/app.js'
}
