function pad(n){ return n<10 ? '0'+n : ''+n; }
function fmtIRL(ts){
  const d = new Date((ts||0)*1000);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
function niceReason(t){
  switch(t){
    case 'DRIVER_CHANGE': return 'New Driver Detected';
    case 'DRIVER_LEFT':   return 'Driver Left Vehicle';
    case 'ELS_ON':        return 'ELS ON';
    case 'ELS_OFF':       return 'ELS OFF';
    case 'DAMAGE':
    case 'CRASH':         return 'Damage';
    default:              return 'Event';
  }
}

let _currentLogs = [];
let _currentPlate = '';

window.addEventListener('message', (e) => {
  const data = e.data;
  if (data.action === 'open') {
    _currentPlate = data.plate;
    _currentLogs = Array.isArray(data.logs) ? data.logs : [];
    document.getElementById('idr').style.display = 'block';
    renderTable();
  } else if (data.action === 'close') {
    document.getElementById('idr').style.display = 'none';
  }
});

function renderTable(){
  const tbody = document.getElementById('idrRows');
  tbody.innerHTML = '';

  _currentLogs.forEach((log) => {
    const tr = document.createElement('tr');

    const tdTime = document.createElement('td');
    tdTime.textContent = `${fmtIRL(log.ts)}`;
    tr.appendChild(tdTime);

    const tdPlayer = document.createElement('td');
    tdPlayer.textContent = log.who || 'Unknown';
    tr.appendChild(tdPlayer);

    const tdSpeed = document.createElement('td');
    const sp = (log.speed||0), lim = (log.limit||0);
    tdSpeed.textContent = `${sp} MPH (${lim} MPH)`;
    tr.appendChild(tdSpeed);

    const tdStreet = document.createElement('td');
    tdStreet.textContent = log.street || '-';
    tr.appendChild(tdStreet);

    const tdHealth = document.createElement('td');
    tdHealth.textContent = (log.engine!=null ? log.engine : '');
    tr.appendChild(tdHealth);

    const tdELS = document.createElement('td');
    const on = !!log.els;
    tdELS.textContent = on ? 'Enabled' : 'Disabled';
    tdELS.className = on ? 'els-enabled' : 'els-disabled';
    tr.appendChild(tdELS);

    const tdReason = document.createElement('td');
    tdReason.textContent = niceReason(log.type);
    tr.appendChild(tdReason);

    tbody.appendChild(tr);
  });
}

document.addEventListener('keydown', (e)=>{
  if (e.key === 'Escape') closeIDR();
});

function closeIDR(){
  document.getElementById('idr').style.display = 'none';
  fetch(`https://${GetParentResourceName()}/close`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:'{}'
  });
}
