local IDR = {}
local dataFile, persistent = nil, false

local function dbg(msg)
    if Config.Debug then print('[EKS_IDR][SERVER] ' .. msg) end
end

local function normalizePlate(p)
    if not p then return 'UNKNOWN' end
    p = tostring(p)
    return (p:gsub('^%s*(.-)%s*$', '%1'))
end

CreateThread(function()
    Wait(200)
    persistent = Config.Persistent
    dataFile = Config.DataFile
    if persistent then LoadData() else IDR = {} end

    if Config.DailyResetEnabled then
        StartDailyResetScheduler()
    end
end)

local function ensurePlate(plate)
    if not IDR[plate] then IDR[plate] = { entries = {} } end
end

local function SaveData()
    if not persistent then return end
    local jsonData = json.encode(IDR, { indent = true })
    SaveResourceFile(GetCurrentResourceName(), dataFile, jsonData, -1)
    dbg('Saved data to ' .. dataFile)
end

function LoadData()
    local content = LoadResourceFile(GetCurrentResourceName(), dataFile)
    if content and #content > 0 then
        local ok, data = pcall(json.decode, content)
        if ok and type(data) == 'table' then
            IDR = data
            dbg(('Loaded %d vehicle records'):format(#(IDR or {})))
            return
        end
    end
    IDR = {}
    dbg('No existing data found; starting fresh')
end

local function ResetAllIDR(reason)
    IDR = {}
    SaveData()  -- writes {} to the file
    dbg(('IDR reset: %s'):format(reason or 'scheduled'))
end

local function msUntilNextReset()
    local now  = os.time()
    local t    = os.date('*t', now)
    local h    = tonumber(Config.DailyResetHour   or 0) % 24
    local m    = tonumber(Config.DailyResetMinute or 0) % 60

    t.hour, t.min, t.sec = h, m, 0
    local target = os.time(t)
    if target <= now then
        target = target + 24 * 60 * 60
    end
    return math.max(1000, (target - now) * 1000)
end

function StartDailyResetScheduler()
    CreateThread(function()
        while true do
            local waitMs = msUntilNextReset()
            dbg(('Next daily reset in %.1f hours'):format(waitMs / 3600000.0))
            Wait(waitMs)
            ResetAllIDR('daily')
        end
    end)
end

RegisterCommand('idrreset', function(src)
    if src == 0 or IsPlayerAceAllowed(src, 'command.idrreset') then
        ResetAllIDR(src == 0 and 'manual (console)' or ('manual (by ' .. GetPlayerName(src) .. ')'))
    else
        if src > 0 then TriggerClientEvent('chat:addMessage', src, { args = { '^1IDR', 'You do not have permission.' } }) end
    end
end, true)

RegisterNetEvent('eks_idr:recordEntry', function(data)
    local src = source
    if not data or not data.plate or not data.type then return end

    local plate = normalizePlate(data.plate)
    ensurePlate(plate)

    local entry = {
        ts     = os.time(),  
        who    = GetPlayerName(src) or ('Player ' .. tostring(src)),
        type   = tostring(data.type),
        speed  = tonumber(data.speed) or 0,
        limit  = tonumber(data.limit) or 0,
        street = tostring(data.street or 'Unknown'),
        engine = tonumber(data.engine) or 0,
        els    = data.els and true or false,
    }

    table.insert(IDR[plate].entries, entry)

    local cap = Config.MaxEntriesPerVehicle or 100
    while #IDR[plate].entries > cap do
        table.remove(IDR[plate].entries, 1)
    end

    dbg(string.format('Saved %s for %s by %s (spd=%d lim=%d street=%s ELS=%s). Count=%d',
        entry.type, plate, entry.who, entry.speed, entry.limit, entry.street, entry.els and 'on' or 'off', #IDR[plate].entries))

    SaveData()
end)

lib.callback.register('eks_idr:getLogs', function(source, plate)
    plate = normalizePlate(plate or '')
    ensurePlate(plate)
    return IDR[plate]
end)
