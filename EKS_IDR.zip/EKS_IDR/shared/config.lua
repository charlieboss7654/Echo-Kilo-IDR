Config = {}

-- Track all vehicles while testing? (overrides IDRModels)

Config.TrackAll = false

-- Only used if TrackAll = false. Keys MUST be lowercase display names.

Config.IDRModels = {
    police   = true,
    police2  = true,
    police3  = true,
    ambulance= true,
    firetruk = true,
    -- add more models you use (lowercase)
}

-- Crash detection thresholds (client uses these)

Config.Crash = {
    EngineDropThreshold = 20.0,   -- drop required to flag damage
    BodyDropThreshold   = 15.0,
    CooldownSeconds     = 3,
    MinImpactSpeedMPH   = 10,     -- must be going at least this fast to consider a collision
    MinSpeedDropMPH     = 8,      -- sudden drop threshold
}

-- ox_target interaction distance

Config.TargetDistance = 3.0

-- Persistence

Config.Persistent = true
Config.DataFile   = 'data/idr.json' -- ensure /data exists

-- Limit per vehicle to prevent huge JSON

Config.MaxEntriesPerVehicle = 100

-- Debug prints (client + server)

Config.Debug = true

-- ===== Daily reset options =====
-- When enabled, the server clears all IDR logs once per day at the time below.

Config.DailyResetEnabled = true

-- 24-hour time (server clock)

Config.DailyResetHour    = 0      -- 0 = midnight
Config.DailyResetMinute  = 0      -- 0..59
